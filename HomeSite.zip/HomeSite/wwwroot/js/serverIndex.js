﻿const createBtn = document.getElementById('create-server');

if (createBtn != null) {
    
}