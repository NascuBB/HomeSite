﻿using HomeSite.Entities;

namespace HomeSite.Models
{
    public class GetFileShareViewModel
    {
        public ShareFileInfo File { get; set; }
        public string Username { get; set; }
    }
}
