﻿namespace HomeSite.Models
{
    public class ModsViewModel
    {
        public string ServerId { get; set; }
        public List<string> Files { get; set; }
        public string Name { get; set; }
        public bool ModsInstalled { get; set; }
    }
}
