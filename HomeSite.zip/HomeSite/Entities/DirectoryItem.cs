﻿namespace HomeSite.Entities
{
    public class DirectoryItem
    {
        public string Name { get; set; } = "";
        public string RelativePath { get; set; } = "";
        public bool IsDirectory { get; set; }
    }
}
