// Auto generated enums from existing versions on host
namespace HomeSite.Generated
{
	public enum ServerCore
	{
	    Forge,
	    Paper,
	}

	public enum Forge
	{
	    _1_12_2,
	    _1_16_5,
	    _1_19_2,
	}

	public enum Paper
	{
	    _1_20_1,
	    _1_21_4,
	}

	public enum MinecraftVersion
	{
	    _1_12_2,
	    _1_16_5,
	    _1_19_2,
	    _1_20_1,
	    _1_21_4,
	}
}
